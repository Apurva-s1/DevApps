﻿namespace ThinkBridge.Inventory.ApplicationContract
{
    public class InventoryServiceResponse
    {
        public string ErrorMessage { get; set; }
    }
}
