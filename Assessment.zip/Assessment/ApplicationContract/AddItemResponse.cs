﻿namespace ThinkBridge.Inventory.ApplicationContract
{
    public class AddItemResponse: InventoryServiceResponse
    {
        public int AddedItemId { get; set; }
    }
}
