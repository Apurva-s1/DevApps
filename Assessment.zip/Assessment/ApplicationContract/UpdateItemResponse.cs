﻿namespace ThinkBridge.Inventory.ApplicationContract
{
    public class UpdateItemResponse : InventoryServiceResponse
    {
    }
}
