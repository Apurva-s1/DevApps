﻿namespace ThinkBridge.Inventory.ApplicationContract
{
    public class RemoveItemResponse: InventoryServiceResponse
    {
    }
}
